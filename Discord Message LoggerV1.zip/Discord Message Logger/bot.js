const discord = require('discord.js');
const { fstat } = require('fs');
const { title } = require('process');
const client = new discord.Client();
const config = require('./config/config');
const PREFIX = "=";
const fs = require('fs')
client.login(config.DISCORD_BOT.TOKEN);
client.on('ready',() => {
    console.log(`${client.user.tag} Has Started Logging.`)
});

client.on('message', function(message) {
    // console.log(message.author.username)
    console.log(message.author.username + " at " + message.createdAt + " in " + message.channel.name + "> " + message.content);
});

const isValidCommand = (message, cmdName) =>  message.content.toLowerCase().startsWith(PREFIX + cmdName)

client.on('message',function(message){
    if(isValidCommand(message, "status")) {
        message.reply("Currently logging");
}
else if(isValidCommand(message, "current")) {
    message.channel.send(new discord.MessageAttachment('./log-file.txt', 'log-file.txt') )
}
else if(isValidCommand(message, "help")) {
    message.reply("The bot is simple, run the code in a terminal with the command (node bot.js > log-file.txt) be aware that doing so resets the txt file. commands use the prefix = and are as follows, help displays this message, status doesnt return anything if the bot isnt working like all the other commands, and current sends the txt file to the channel")
}
});